@javax.xml.bind.annotation.XmlSchema(namespace = "http://mgsv.unt.edu/")
package edu.unt.mgsv.client;
