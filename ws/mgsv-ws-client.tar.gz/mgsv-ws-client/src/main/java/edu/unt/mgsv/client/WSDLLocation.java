package edu.unt.mgsv.client;

public class WSDLLocation {
	public static String WSDL = "http://cas-bioinfo.cas.unt.edu:8081/MGSVService?wsdl";
}
